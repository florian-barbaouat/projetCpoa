**Date** : le vendredi 23 novembre 2017

**Format** : environ 20 minutes pour la Démo + Présentation. Il est souhaitable que tous les membres du groupe prennent la parole. Le travail effectué par chaque membre doit être bien précisé.

La démonstration se déroulera selon le scénario suivant :

0. Nous allons vous donner votre code source que vous nous aurez envoyé le mercredi 20 novembre 2017.
1. À partir d'un TERMINAL (pas depuis une IDE) vous allez le construire. Attention donc à ceux qui ont utilisé les éditeurs d'interfaces graphiques : il faut que votre code soit portable.
2. Vous l'exécutez ensuite.
3. Démonstration des fonctionnalités
4. Questions 

Pensez à préparer votre présentation car 20 minutes c'est très court pour, à la fois, présenter le travail effectué et justifier les choix techniques.
