package fr.univ_amu.iut.reseauferre.traitement.wagons;

/**
 * wagon de déchets nucléaires
 * @see Wagon
 */
public class WagonDechetNucleaire extends Wagon {
}
