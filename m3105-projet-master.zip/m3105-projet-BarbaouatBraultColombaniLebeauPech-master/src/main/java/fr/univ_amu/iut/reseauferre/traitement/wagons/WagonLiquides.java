package fr.univ_amu.iut.reseauferre.traitement.wagons;

/**
 * wagon de transports de liquides
 * @see Wagon
 */
public class WagonLiquides extends Wagon {
}
