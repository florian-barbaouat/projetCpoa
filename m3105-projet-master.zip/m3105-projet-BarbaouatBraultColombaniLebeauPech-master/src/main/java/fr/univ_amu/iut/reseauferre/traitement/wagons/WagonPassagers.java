package fr.univ_amu.iut.reseauferre.traitement.wagons;

/**
 * Wagon de passagers
 * @see Wagon
 */
public class WagonPassagers extends Wagon {
}
