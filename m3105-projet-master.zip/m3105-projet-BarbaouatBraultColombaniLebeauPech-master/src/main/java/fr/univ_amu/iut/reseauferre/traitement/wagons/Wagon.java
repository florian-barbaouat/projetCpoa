package fr.univ_amu.iut.reseauferre.traitement.wagons;

/**
 * interface des wagons suivant un train
 */
public abstract class Wagon {

}
