package fr.univ_amu.iut.reseauferre.affichage.simplifie.vue;

import fr.univ_amu.iut.reseauferre.affichage.simplifie.modele.Donnees;

public interface Vue {
    void afficher(Donnees donnees);
}
