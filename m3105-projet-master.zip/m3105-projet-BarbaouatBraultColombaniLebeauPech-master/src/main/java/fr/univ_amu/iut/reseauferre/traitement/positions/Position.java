package fr.univ_amu.iut.reseauferre.traitement.positions;

/**
 * Interface Position représentant la position des trains
 */
public interface Position {

    String getName();
}
