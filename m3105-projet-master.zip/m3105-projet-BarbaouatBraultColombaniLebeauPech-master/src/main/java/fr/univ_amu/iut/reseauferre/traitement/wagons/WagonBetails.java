package fr.univ_amu.iut.reseauferre.traitement.wagons;

/**
 * wagon de bétails
 * @see Wagon
 */
public class WagonBetails extends Wagon {
}
