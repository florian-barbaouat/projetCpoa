package fr.univ_amu.iut.reseauferre.traitement.wagons;

/**
 * wagon de déchets liquides
 * @see Wagon
 */
public class WagonDechetLiquides extends Wagon {
}
