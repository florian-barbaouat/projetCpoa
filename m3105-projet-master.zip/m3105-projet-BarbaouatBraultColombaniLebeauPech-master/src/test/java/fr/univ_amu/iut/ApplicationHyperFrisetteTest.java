package fr.univ_amu.iut;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class ApplicationHyperFrisetteTest {
    @Test
    public void test_should_fail() {
        assertTrue("Really serious test !!!", true);
    }
}